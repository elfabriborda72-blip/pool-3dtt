# Pool 3D - 8 Ball

Juego de Pool (billar) 8-ball en 3D optimizado para **celular** y escritorio.

## Características actuales

- Mesa 3D con física (Three.js + cannon-es)
- 16 bolas
- **Control clásico de potencia móvil**: arrastra hacia atrás para cargar potencia y apuntar, suelta para tirar
- Efecto (spin) básico con botones
- Detección de troneras
- Cámara orbital + vista superior
- Interfaz táctil adaptada a móvil

## Cómo jugar (móvil)

1. Toca la pantalla cerca de la bola blanca
2. Arrastra el dedo **hacia atrás** para cargar potencia (cuanto más lejos, más fuerte)
3. La dirección del arrastre define la puntería
4. Suelta el dedo para tirar
5. Usa los botones ↺ ↻ para aplicar efecto (sidespin)

## Controles escritorio

- Mismo sistema de arrastre con el mouse
- Rueda del mouse / dos dedos para zoom
- Arrastrar con dos dedos o botón derecho para rotar cámara (cuando no estás tirando)

## Cómo ejecutar

### Opción 1: Abrir directamente
Simplemente abre `index.html` en un navegador moderno (Chrome, Safari, Firefox).

### Opción 2: Servidor local (recomendado)
```bash
npx serve .
# o
python -m http.server 3000
```

Luego abre http://localhost:3000 en el celular (misma red) o en la PC.

## Subir a GitHub

```bash
git init
git add .
git commit -m "Pool 3D - versión inicial con control móvil clásico"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/pool-3d.git
git push -u origin main
```

Luego activa **GitHub Pages** en Settings → Pages → Source: main branch.

## Próximas mejoras (versión avanzada)

- [ ] Texturas realistas de bolas (números + stripes)
- [ ] Física de spin más realista (English + backspin/topspin)
- [ ] Reglas completas de 8-ball (asignación de sólidas/rayadas, faltas, etc.)
- [ ] Mejor detección de colisiones y rebotes en bandas
- [ ] Sonidos
- [ ] Indicador de línea de tiro con predicción
- [ ] Modo 9-ball
- [ ] Multijugador local mejorado

## Stack

- Three.js (renderizado 3D)
- cannon-es (física)
- HTML/CSS/JS puro (sin build, perfecto para GitHub Pages y móvil)

---

Hecho para jugar en el celular.
