import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import * as CANNON from 'cannon-es';

// ===================== CONFIG =====================
const BALL_RADIUS = 0.0286;          // ~57.2mm diameter (real size scaled)
const TABLE_LENGTH = 2.54;           // 9ft table approx (scaled)
const TABLE_WIDTH = 1.27;
const CUSHION_HEIGHT = 0.04;
const POCKET_RADIUS = 0.06;

const BALL_COLORS = {
  0: 0xffffff, // cue
  1: 0xfacc15, // yellow
  2: 0x3b82f6, // blue
  3: 0xef4444, // red
  4: 0x8b5cf6, // purple
  5: 0xf97316, // orange
  6: 0x22c55e, // green
  7: 0x7f1d1d, // maroon
  8: 0x111111, // black
  9: 0xfacc15,
  10: 0x3b82f6,
  11: 0xef4444,
  12: 0x8b5cf6,
  13: 0xf97316,
  14: 0x22c55e,
  15: 0x7f1d1d
};

// ===================== STATE =====================
let scene, camera, renderer, controls;
let world;
let balls = [];          // { mesh, body, number, pocketed }
let cueBall = null;
let tableMeshes = [];
let isAiming = false;
let isCharging = false;
let aimDirection = new THREE.Vector3(1, 0, 0);
let power = 0;
let maxPower = 12;
let spin = 0;            // -1 to 1 (sidespin)
let currentPlayer = 1;
let gameState = 'waiting'; // waiting | aiming | simulating | gameover
let cameraMode = 'orbit'; // orbit | top

// Touch state for classic control
let touchStart = null;
let touchCurrent = null;
let guideLine = null;
let powerIndicator = null;

// DOM
const canvas = document.getElementById('game');
const messageEl = document.getElementById('message');
const playerEl = document.getElementById('current-player');
const ballsInfoEl = document.getElementById('balls-info');
const powerContainer = document.getElementById('power-container');
const powerFill = document.getElementById('power-fill');
const btnCamera = document.getElementById('btn-camera');
const btnReset = document.getElementById('btn-reset');
const btnSpinLeft = document.getElementById('btn-spin-left');
const btnSpinRight = document.getElementById('btn-spin-right');

// ===================== INIT =====================
function init() {
  // Renderer
  renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.outputColorSpace = THREE.SRGBColorSpace;

  // Scene
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x0f172a);
  scene.fog = new THREE.Fog(0x0f172a, 8, 20);

  // Camera
  camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 0.1, 50);
  camera.position.set(0, 2.2, 2.8);
  camera.lookAt(0, 0, 0);

  // Lights
  const ambient = new THREE.AmbientLight(0xffffff, 0.45);
  scene.add(ambient);

  const dirLight = new THREE.DirectionalLight(0xffffff, 1.1);
  dirLight.position.set(2, 5, 3);
  dirLight.castShadow = true;
  dirLight.shadow.mapSize.set(1024, 1024);
  dirLight.shadow.camera.near = 0.5;
  dirLight.shadow.camera.far = 15;
  dirLight.shadow.camera.left = -3;
  dirLight.shadow.camera.right = 3;
  dirLight.shadow.camera.top = 3;
  dirLight.shadow.camera.bottom = -3;
  scene.add(dirLight);

  const spot = new THREE.SpotLight(0xffffff, 0.6);
  spot.position.set(0, 4, 0);
  spot.angle = Math.PI / 4;
  spot.penumbra = 0.4;
  spot.castShadow = true;
  scene.add(spot);

  // Orbit controls (desktop + two-finger on mobile when not aiming)
  controls = new OrbitControls(camera, canvas);
  controls.enableDamping = true;
  controls.dampingFactor = 0.08;
  controls.maxPolarAngle = Math.PI / 2.1;
  controls.minDistance = 1.5;
  controls.maxDistance = 6;
  controls.target.set(0, 0, 0);
  controls.enabled = true;

  // Physics world
  world = new CANNON.World({
    gravity: new CANNON.Vec3(0, -9.82, 0)
  });
  world.broadphase = new CANNON.NaiveBroadphase();
  world.solver.iterations = 15;
  world.allowSleep = true;

  // Materials
  const ballMaterial = new CANNON.Material('ball');
  const cushionMaterial = new CANNON.Material('cushion');
  const tableMaterial = new CANNON.Material('table');

  const ballBall = new CANNON.ContactMaterial(ballMaterial, ballMaterial, {
    friction: 0.06,
    restitution: 0.92
  });
  const ballCushion = new CANNON.ContactMaterial(ballMaterial, cushionMaterial, {
    friction: 0.2,
    restitution: 0.75
  });
  const ballTable = new CANNON.ContactMaterial(ballMaterial, tableMaterial, {
    friction: 0.25,
    restitution: 0.15
  });

  world.addContactMaterial(ballBall);
  world.addContactMaterial(ballCushion);
  world.addContactMaterial(ballTable);

  // Create table
  createTable(tableMaterial, cushionMaterial);

  // Create balls
  createBalls(ballMaterial);

  // Guide line
  createGuideLine();

  // Events
  setupEvents();

  // Start loop
  animate();
  setMessage('Arrastra hacia atrás para tirar');
}

// ===================== TABLE =====================
function createTable(tableMat, cushionMat) {
  const halfL = TABLE_LENGTH / 2;
  const halfW = TABLE_WIDTH / 2;

  // Cloth (visual)
  const clothGeo = new THREE.BoxGeometry(TABLE_LENGTH, 0.02, TABLE_WIDTH);
  const clothMat = new THREE.MeshStandardMaterial({
    color: 0x166534,
    roughness: 0.85,
    metalness: 0.05
  });
  const cloth = new THREE.Mesh(clothGeo, clothMat);
  cloth.position.y = -0.01;
  cloth.receiveShadow = true;
  scene.add(cloth);

  // Physics floor
  const floorBody = new CANNON.Body({
    mass: 0,
    shape: new CANNON.Box(new CANNON.Vec3(halfL, 0.01, halfW)),
    material: tableMat
  });
  floorBody.position.set(0, -0.02, 0);
  world.addBody(floorBody);

  // Rails / cushions (simplified boxes)
  const cushionThickness = 0.06;
  const cushionY = CUSHION_HEIGHT / 2;

  const cushions = [
    // Long sides
    { pos: [0, cushionY, halfW + cushionThickness / 2], size: [halfL - 0.08, CUSHION_HEIGHT / 2, cushionThickness / 2] },
    { pos: [0, cushionY, -halfW - cushionThickness / 2], size: [halfL - 0.08, CUSHION_HEIGHT / 2, cushionThickness / 2] },
    // Short sides
    { pos: [halfL + cushionThickness / 2, cushionY, 0], size: [cushionThickness / 2, CUSHION_HEIGHT / 2, halfW - 0.08] },
    { pos: [-halfL - cushionThickness / 2, cushionY, 0], size: [cushionThickness / 2, CUSHION_HEIGHT / 2, halfW - 0.08] }
  ];

  const woodMat = new THREE.MeshStandardMaterial({ color: 0x5c3317, roughness: 0.6, metalness: 0.1 });

  cushions.forEach(c => {
    const geo = new THREE.BoxGeometry(c.size[0] * 2, c.size[1] * 2, c.size[2] * 2);
    const mesh = new THREE.Mesh(geo, woodMat);
    mesh.position.set(...c.pos);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    scene.add(mesh);

    const body = new CANNON.Body({
      mass: 0,
      shape: new CANNON.Box(new CANNON.Vec3(...c.size)),
      material: cushionMat
    });
    body.position.set(...c.pos);
    world.addBody(body);
  });

  // Simple pockets (visual + sensors later)
  const pocketPositions = [
    [-halfL, 0, -halfW], [0, 0, -halfW], [halfL, 0, -halfW],
    [-halfL, 0, halfW],  [0, 0, halfW],  [halfL, 0, halfW]
  ];

  pocketPositions.forEach(p => {
    const geo = new THREE.CylinderGeometry(POCKET_RADIUS, POCKET_RADIUS, 0.05, 16);
    const mat = new THREE.MeshBasicMaterial({ color: 0x000000 });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(p[0], -0.02, p[2]);
    mesh.rotation.x = Math.PI / 2;
    scene.add(mesh);
  });
}

// ===================== BALLS =====================
function createBalls(ballMat) {
  // Clear previous
  balls.forEach(b => {
    scene.remove(b.mesh);
    world.removeBody(b.body);
  });
  balls = [];

  const positions = rackPositions();

  for (let i = 0; i <= 15; i++) {
    const isCue = i === 0;
    const pos = isCue ? new THREE.Vector3(-TABLE_LENGTH * 0.25, BALL_RADIUS, 0) : positions[i - 1];

    // Visual
    const geo = new THREE.SphereGeometry(BALL_RADIUS, 24, 24);
    const color = BALL_COLORS[i] || 0xffffff;
    const mat = new THREE.MeshStandardMaterial({
      color,
      roughness: 0.25,
      metalness: 0.1
    });

    // Simple number texture for solid/stripe indication
    if (i > 0) {
      // For advanced later: better textures
    }

    const mesh = new THREE.Mesh(geo, mat);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    mesh.position.copy(pos);
    scene.add(mesh);

    // Physics
    const body = new CANNON.Body({
      mass: 0.17, // ~170g
      shape: new CANNON.Sphere(BALL_RADIUS),
      material: ballMat,
      linearDamping: 0.35,
      angularDamping: 0.4
    });
    body.position.set(pos.x, pos.y, pos.z);
    body.allowSleep = true;
    body.sleepSpeedLimit = 0.08;
    body.sleepTimeLimit = 0.5;
    world.addBody(body);

    const ball = { mesh, body, number: i, pocketed: false };
    balls.push(ball);
    if (isCue) cueBall = ball;
  }
}

function rackPositions() {
  // Standard triangle rack centered near the foot
  const startX = TABLE_LENGTH * 0.25;
  const r = BALL_RADIUS * 2.02;
  const positions = [];
  let idx = 0;
  for (let row = 0; row < 5; row++) {
    for (let col = 0; col <= row; col++) {
      const x = startX + row * r * Math.cos(Math.PI / 6);
      const z = (col - row / 2) * r;
      positions.push(new THREE.Vector3(x, BALL_RADIUS, z));
      idx++;
    }
  }
  // Order: 1 at apex is fine for now (we can shuffle later for real rack)
  return positions;
}

// ===================== GUIDE LINE =====================
function createGuideLine() {
  const geo = new THREE.BufferGeometry().setFromPoints([
    new THREE.Vector3(), new THREE.Vector3(1, 0, 0)
  ]);
  const mat = new THREE.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.7 });
  guideLine = new THREE.Line(geo, mat);
  guideLine.visible = false;
  scene.add(guideLine);
}

function updateGuideLine() {
  if (!cueBall || gameState !== 'aiming' && gameState !== 'waiting') {
    guideLine.visible = false;
    return;
  }

  const origin = cueBall.mesh.position.clone();
  origin.y = BALL_RADIUS + 0.001;

  const dir = aimDirection.clone().normalize();
  const length = 0.8 + power * 0.08;

  const points = [
    origin,
    origin.clone().add(dir.multiplyScalar(length))
  ];

  guideLine.geometry.setFromPoints(points);
  guideLine.visible = true;
}

// ===================== CONTROLS (CLASSIC MOBILE) =====================
function setupEvents() {
  // Touch / Mouse for classic power
  canvas.addEventListener('pointerdown', onPointerDown);
  canvas.addEventListener('pointermove', onPointerMove);
  canvas.addEventListener('pointerup', onPointerUp);
  canvas.addEventListener('pointercancel', onPointerUp);

  // Buttons
  btnCamera.addEventListener('click', toggleCameraMode);
  btnReset.addEventListener('click', resetGame);
  btnSpinLeft.addEventListener('click', () => { spin = Math.max(-1, spin - 0.25); setMessage(`Efecto: ${spin.toFixed(2)}`); });
  btnSpinRight.addEventListener('click', () => { spin = Math.min(1, spin + 0.25); setMessage(`Efecto: ${spin.toFixed(2)}`); });

  window.addEventListener('resize', onResize);

  // Prevent default gestures
  document.addEventListener('gesturestart', e => e.preventDefault());
  document.addEventListener('gesturechange', e => e.preventDefault());
}

function onPointerDown(e) {
  if (gameState === 'simulating') return;

  // Only start aiming if near cue ball or already aiming
  const rect = canvas.getBoundingClientRect();
  const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
  const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

  touchStart = { x: e.clientX, y: e.clientY };
  touchCurrent = { x: e.clientX, y: e.clientY };
  isAiming = true;
  isCharging = true;
  gameState = 'aiming';
  controls.enabled = false;

  powerContainer.classList.remove('hidden');
  updateAimFromTouch();
  setMessage('Arrastra hacia atrás para potencia');
}

function onPointerMove(e) {
  if (!isCharging || !touchStart) return;

  touchCurrent = { x: e.clientX, y: e.clientY };
  updateAimFromTouch();
}

function onPointerUp(e) {
  if (!isCharging) return;

  isCharging = false;
  isAiming = false;
  controls.enabled = true;
  powerContainer.classList.add('hidden');
  guideLine.visible = false;

  if (power > 0.15) {
    shoot();
  } else {
    gameState = 'waiting';
    setMessage('Arrastra hacia atrás para tirar');
  }

  touchStart = null;
  touchCurrent = null;
  power = 0;
  powerFill.style.width = '0%';
}

function updateAimFromTouch() {
  if (!touchStart || !touchCurrent || !cueBall) return;

  const dx = touchCurrent.x - touchStart.x;
  const dy = touchCurrent.y - touchStart.y;

  // Classic: drag BACK increases power. Direction of drag sets aim.
  // We invert so dragging "away" from the target direction loads power.
  const dist = Math.sqrt(dx * dx + dy * dy);
  power = Math.min(maxPower, dist / 40); // sensitivity

  powerFill.style.width = `${(power / maxPower) * 100}%`;

  // Aim direction: opposite of drag vector projected on table
  // Simple 2D approximation using screen drag
  const angle = Math.atan2(dx, -dy); // adjust depending on camera
  // Better: use current camera to project
  const camDir = new THREE.Vector3();
  camera.getWorldDirection(camDir);
  camDir.y = 0;
  camDir.normalize();

  const right = new THREE.Vector3().crossVectors(camDir, new THREE.Vector3(0, 1, 0)).normalize();

  // Drag relative
  const dragForward = -dy / 100;
  const dragSide = dx / 100;

  aimDirection.set(0, 0, 0)
    .addScaledVector(camDir, dragForward)
    .addScaledVector(right, dragSide);

  if (aimDirection.lengthSq() < 0.0001) {
    aimDirection.copy(camDir);
  }
  aimDirection.y = 0;
  aimDirection.normalize();

  // Flip so that dragging "back" aims forward
  aimDirection.negate();

  updateGuideLine();
}

function shoot() {
  if (!cueBall || power < 0.1) return;

  gameState = 'simulating';
  setMessage('...');

  const impulse = aimDirection.clone().multiplyScalar(power * 0.55);
  cueBall.body.wakeUp();
  cueBall.body.applyImpulse(
    new CANNON.Vec3(impulse.x, 0, impulse.z),
    new CANNON.Vec3(0, 0, 0) // center for now; later offset for spin
  );

  // Basic sidespin
  if (Math.abs(spin) > 0.05) {
    cueBall.body.angularVelocity.set(0, spin * power * 2.5, 0);
  }

  // Reset spin for next shot
  spin = 0;
}

// ===================== GAME LOOP =====================
function animate() {
  requestAnimationFrame(animate);

  const dt = 1 / 60;
  world.step(dt);

  // Sync balls
  let anyMoving = false;
  balls.forEach(b => {
    if (b.pocketed) return;

    b.mesh.position.copy(b.body.position);
    b.mesh.quaternion.copy(b.body.quaternion);

    const speed = b.body.velocity.length();
    if (speed > 0.05) anyMoving = true;

    // Simple pocket detection
    checkPocket(b);
  });

  // When all stop
  if (gameState === 'simulating' && !anyMoving) {
    onAllBallsStopped();
  }

  if (controls.enabled) controls.update();
  updateGuideLine();
  renderer.render(scene, camera);
}

function checkPocket(ball) {
  const halfL = TABLE_LENGTH / 2;
  const halfW = TABLE_WIDTH / 2;
  const p = ball.body.position;

  const pockets = [
    [-halfL, -halfW], [0, -halfW], [halfL, -halfW],
    [-halfL, halfW],  [0, halfW],  [halfL, halfW]
  ];

  for (const [px, pz] of pockets) {
    const dist = Math.sqrt((p.x - px) ** 2 + (p.z - pz) ** 2);
    if (dist < POCKET_RADIUS * 0.9 && p.y < BALL_RADIUS * 1.5) {
      // Pocketed
      ball.pocketed = true;
      ball.body.velocity.set(0, 0, 0);
      ball.body.angularVelocity.set(0, 0, 0);
      ball.body.position.set(0, -1, 0); // hide under table
      ball.mesh.visible = false;
      world.removeBody(ball.body);

      if (ball.number === 0) {
        setMessage('¡Falta! Bola blanca en tronera');
        // Respawn cue later
      } else if (ball.number === 8) {
        setMessage('¡Bola 8!');
      }
      break;
    }
  }
}

function onAllBallsStopped() {
  gameState = 'waiting';
  // Basic turn logic placeholder
  currentPlayer = currentPlayer === 1 ? 2 : 1;
  playerEl.textContent = `Jugador ${currentPlayer}`;
  setMessage('Arrastra hacia atrás para tirar');

  // Respawn cue if pocketed
  if (cueBall.pocketed) {
    cueBall.pocketed = false;
    cueBall.mesh.visible = true;
    cueBall.body.position.set(-TABLE_LENGTH * 0.25, BALL_RADIUS, 0);
    cueBall.body.velocity.set(0, 0, 0);
    cueBall.body.angularVelocity.set(0, 0, 0);
    world.addBody(cueBall.body);
  }
}

function toggleCameraMode() {
  if (cameraMode === 'orbit') {
    cameraMode = 'top';
    camera.position.set(0, 4.5, 0.01);
    camera.lookAt(0, 0, 0);
    controls.target.set(0, 0, 0);
    controls.enabled = false;
  } else {
    cameraMode = 'orbit';
    camera.position.set(0, 2.2, 2.8);
    controls.enabled = true;
  }
}

function resetGame() {
  createBalls(new CANNON.Material('ball'));
  currentPlayer = 1;
  playerEl.textContent = 'Jugador 1';
  ballsInfoEl.textContent = '—';
  gameState = 'waiting';
  setMessage('Arrastra hacia atrás para tirar');
  spin = 0;
}

function setMessage(txt) {
  messageEl.textContent = txt;
}

function onResize() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
}

// Start
init();
